import { useState, useEffect } from 'react';
import { ArrowLeft, Users, Radio, LifeBuoy, Bot, Zap, RefreshCw, Activity, Play, AlertCircle, Wifi, Clock } from 'lucide-react';
import { supabase } from '../services/supabaseClient';
import { fetchAdminSummaryStats } from '../services/adminMetrics';
import AdminSupportInbox from '../components/admin/AdminSupportInbox';
import LiveSparkline from '../components/admin/LiveSparkline';

export default function AdminDashboard({ onBack, onViewProject }: any) {
  const [summaryStats, setSummaryStats] = useState<any>(null);
  const [transcripts, setTranscripts] = useState<any[]>([]);
  const [liveTelemetry, setLiveTelemetry] = useState<Record<string, number[]>>({});
  const [loading, setLoading] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);
  const [connStatus, setConnStatus] = useState<'Linked' | 'Offline'>('Offline');
  const [errorLog, setErrorLog] = useState<string | null>(null);

  useEffect(() => {
    loadMissionControlData();
    const channel = supabase.channel('mission-radar-final-v20')
      .on('postgres_changes', { event: 'INSERT', table: 'measurements', schema: 'public' }, (payload) => {
        const newPing = payload?.new;
        if (newPing?.user_id && typeof newPing?.rsrp === 'number') {
          setLiveTelemetry(prev => ({
            ...prev,
            [newPing.user_id]: [...(prev[newPing.user_id] || []), newPing.rsrp].slice(-20)
          }));
        }
      })
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') setConnStatus('Linked');
        else setConnStatus('Offline');
      });
    return () => { supabase.removeChannel(channel); };
  }, []);

  const loadMissionControlData = async () => {
    setLoading(true);
    try {
      const [stats, chatLogs] = await Promise.all([
        fetchAdminSummaryStats().catch(() => null),
        supabase.from('chat_transcripts').select('*').order('updated_at', { ascending: false }).limit(4)
      ]);
      setSummaryStats(stats || {});
      setTranscripts(chatLogs?.data || []);
    } catch (e) {}
    setLoading(false);
  };

  const simulatePing = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    setIsSimulating(true); setErrorLog(null);
    try {
      let { data: projects } = await supabase.from('projects').select('id').eq('name', 'TEST').limit(1);
      let pId = projects?.[0]?.id;
      if (!pId) {
        const { data: newP } = await supabase.from('projects').insert({ name: 'TEST', user_id: user.id }).select().single();
        pId = newP?.id;
      }
      let { data: floors } = await supabase.from('floors').select('id, project_id').eq('project_id', pId).limit(1);
      let fId = floors?.[0]?.id;
      if (!fId) {
        const { data: newF } = await supabase.from('floors').insert({ name: 'Level 1', project_id: pId }).select().single();
        fId = newF?.id;
      }

      // CLAUDE-VERIFIED PAYLOAD - SNAKE_CASE
      const { error } = await supabase.from('measurements').insert({
        user_id: user.id,
        project_id: pId,
        floor_id: fId,
        x: 0.5,
        y: 0.5,
        location_number: 1,
        rsrp: Math.floor(Math.random() * 30) - 100,
        rsrq: -12,
        sinr: 15,
        rssi: -80,
        cell_id: 'TEST-NODE',
        tech_type: '5G',
        carrier_name: 'T-Mobile',
        timestamp: new Date().toISOString(),
        created_at: new Date().toISOString()
      });
      if (error) setErrorLog(error.message);
    } catch (e: any) { setErrorLog(e.message); }
    setTimeout(() => setIsSimulating(false), 200);
  };

  return (
    <div className="min-h-screen bg-black text-white font-sans pb-24">
      
      {/* HEADER - MIXED CASE BRANDING */}
      <div className="h-32 border-b border-white/5 bg-black/90 backdrop-blur-xl sticky top-0 z-50 px-5 pt-12 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 text-slate-500 hover:text-[#27AAE1] transition-colors active:scale-95"><ArrowLeft size={22} /></button>
          <div className="h-5 w-px bg-white/10" />
          <div>
            <h2 className="text-xs font-bold text-[#27AAE1] mb-0.5 force-mixed-case">GoFlexConnect</h2>
            <h1 className="text-xl font-bold text-white tracking-tight force-mixed-case">Mission Control</h1>
          </div>
        </div>
        
        <div className="flex gap-2 items-center">
          <div className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
            <div className={`w-1.5 h-1.5 rounded-full ${connStatus === 'Linked' ? 'bg-green-500 shadow-[0_0_8px_#22c55e]' : 'bg-red-500 animate-pulse'}`} />
            <span className="text-[10px] font-bold text-white">{connStatus}</span>
          </div>
          <button onClick={simulatePing} className={`p-2 rounded-lg transition-all ${isSimulating ? 'bg-[#27AAE1]/20 text-[#27AAE1]' : 'text-slate-600 hover:text-slate-400'}`}><Play size={18} fill={isSimulating ? "currentColor" : "none"} /></button>
          <button onClick={loadMissionControlData} className={`p-2 text-slate-500 hover:text-slate-300 transition-colors ${loading ? 'animate-spin' : ''}`}><RefreshCw size={18} /></button>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-4 py-6 space-y-6">
        
        {errorLog && (
          <div className="bg-red-500/20 border border-red-500/50 p-4 rounded-xl text-xs text-red-400 font-mono">{errorLog}</div>
        )}

        {/* LIVE RADAR - TOP PRIORITY, SINGLE COLUMN, HUGE TEXT */}
        <div className="bg-[#0A0F1A] border border-[#27AAE1]/30 rounded-3xl p-5 shadow-[0_0_30px_rgba(39,170,225,0.15)]">
          <div className="flex items-center gap-3 mb-6">
            <Activity className="text-[#27AAE1] animate-pulse" size={22} />
            <h2 className="text-lg font-bold text-white" style={{ textTransform: 'none !important' }}>Live Radar</h2>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {Object.entries(liveTelemetry).map(([id, pings]) => (
              <div key={id} className="bg-black/70 border border-white/5 rounded-[2rem] p-5 flex items-center justify-between gap-4 shadow-xl min-h-[140px]">
                <div className="flex-shrink-0">
                  <p className="text-[9px] font-bold text-[#27AAE1] uppercase mb-2 tracking-wide">Node: {id.slice(0, 8)}</p>
                  <p className="text-6xl font-bold text-white leading-none tracking-tighter">
                    {pings[pings.length - 1] || '--'}
                    <span className="text-base text-slate-500 font-normal ml-2">dBm</span>
                  </p>
                </div>
                <div className="flex-1 h-24 max-w-[65%]">
                  <LiveSparkline data={pings || []} />
                </div>
              </div>
            ))}
            
            {Object.keys(liveTelemetry).length === 0 && (
              <div className="text-center py-16 border border-dashed border-white/5 rounded-3xl">
                <Wifi size={32} className="mx-auto mb-3 text-slate-700 opacity-40" />
                <p className="text-xs font-bold text-slate-600" style={{ textTransform: 'none !important' }}>Awaiting field uplink...</p>
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-slate-900/40 border border-white/5 rounded-3xl p-6 shadow-xl">
            <h2 className="text-lg font-bold mb-6 flex items-center gap-2 text-white" style={{ textTransform: 'none !important' }}><LifeBuoy className="text-[#27AAE1]" size={20} /> Support Radar</h2>
            <AdminSupportInbox />
          </div>
          <div className="bg-slate-900/40 border border-white/5 rounded-3xl p-6 shadow-xl h-[500px] flex flex-col">
            <h2 className="text-lg font-bold mb-6 flex items-center gap-2 text-white" style={{ textTransform: 'none !important' }}><Bot className="text-green-400" size={20} /> Assistant Feed</h2>
            <div className="flex-1 overflow-y-auto space-y-3 scrollbar-hide">
              {transcripts.map((chat) => (
                <div key={chat.id} className="p-4 bg-white/5 border border-white/5 rounded-2xl">
                  <div className="flex justify-between items-center mb-1">
                    <p className="text-[9px] font-bold text-[#27AAE1]">{chat?.user_email?.split('@')[0] || 'User'}</p>
                    <Clock size={10} className="text-slate-600" />
                  </div>
                  <p className="text-[11px] text-slate-400 line-clamp-2">"{chat?.messages?.[chat.messages.length - 1]?.content || 'Uplink active'}"</p>
                </div>
              ))}
            </div>
          </div>
        
        {/* USER MANAGEMENT */}
        <div className="bg-slate-900/40 border border-white/5 rounded-3xl p-6 shadow-xl">
          <h2 className="text-lg font-bold mb-6 flex items-center gap-2 text-white" style={{ textTransform: 'none !important' }}><Users className="text-purple-400" size={20} /> User Management</h2>
          <button
            onClick={async () => {
              const userId = prompt('Enter User ID to reset onboarding:');
              if (userId) {
                try {
                  const { error } = await supabase.from('user_profiles').update({ has_completed_onboarding: false }).eq('user_id', userId);
                  if (error) alert('Error: ' + error.message);
                  else alert('? Onboarding reset for user ' + userId);
                } catch (e) { alert('Failed to reset'); }
              }
            }}
            className="w-full py-3 bg-purple-800/20 border border-purple-500/30 rounded-xl text-xs font-bold text-purple-400 uppercase tracking-wider hover:bg-purple-800/30 transition-colors"
          >
            Reset User Onboarding
          </button>
        </div>
</div>
      </div>
    </div>
  );
}

