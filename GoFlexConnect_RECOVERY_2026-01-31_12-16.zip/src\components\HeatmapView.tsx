import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Settings as SettingsIcon, Flame, Target, Database } from 'lucide-react';
import { useStore } from '../store/useStore';
import { getMetricValue, getColorForValue } from '../utils/calculations';
import { MetricType } from '../types';
import ZoomableFloorPlan from './ZoomableFloorPlan';

export default function HeatmapView({ projectId, floorId, onBack }: any) {
  const { projects, floors, measurements: allMs, settings, updateSettings } = useStore();
  const project = projects.find((p) => p.id === projectId);
  const floor = floors.find((f) => f.id === floorId) || floors.find(f => f.project_id === projectId);
  const mapImage = floor?.image_data || floor?.floorPlanImage || project?.floorPlanImage;

  const [viewMode, setViewMode] = useState<'heatmap' | 'points'>('heatmap');
  const [selectedMetric, setSelectedMetric] = useState<MetricType>('rsrp');
  const [showSettings, setShowSettings] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const measurements = floorId
    ? allMs.filter((m) => m.floorId === floorId || m.floor_id === floorId)
    : allMs.filter((m) => m.projectId === projectId);

  useEffect(() => {
    if (!canvasRef.current || measurements.length === 0) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const radius = 250; 
    const gridSize = 4; 

    for (let x = 0; x < canvas.width; x += gridSize) {
      for (let y = 0; y < canvas.height; y += gridSize) {
        let weightedSum = 0, totalWeight = 0;
        let hasSignal = false;
        measurements.forEach((m) => {
          const dx = x - (m.x * canvas.width);
          const dy = y - (m.y * canvas.height);
          const distSq = dx * dx + dy * dy;
          if (distSq < radius * radius) {
            const dist = Math.sqrt(distSq);
            const weight = Math.pow(1 - dist / radius, 2);
            weightedSum += getMetricValue(m, selectedMetric) * weight;
            totalWeight += weight;
            hasSignal = true;
          }
        });
        if (hasSignal && totalWeight > 0) {
          const val = weightedSum / totalWeight;
          ctx.fillStyle = getColorForValue(val, selectedMetric, settings.thresholds, settings.benchmarkMode, settings.rsrpTarget);
          ctx.globalAlpha = Math.min(totalWeight * 0.8, 1.0);
          ctx.fillRect(x, y, gridSize, gridSize);
        }
      }
    }
  }, [measurements, viewMode, selectedMetric, settings]);

  if (!project) return null;

  return (
    <div className="fixed inset-0 bg-black flex flex-col overflow-hidden text-white z-[1000]">
      <div className="shrink-0 bg-slate-900 border-b border-white/5 pt-12 pb-4 px-6 z-30">
        <div className="flex items-center justify-between mb-4">
          <button onClick={onBack} className="p-2 bg-white/5 rounded-xl text-[#27AAE1]"><ArrowLeft size={22} /></button>
          <div className="flex flex-col items-center">
            <h1 className="text-sm font-black tracking-[0.1em] italic text-white/80">RF Simulation</h1>
            <span className="text-[10px] font-bold text-[#27AAE1] uppercase tracking-widest">{project.name}</span>
          </div>
          <button onClick={() => setShowSettings(!showSettings)} className={`p-2 rounded-xl ${showSettings ? 'bg-[#27AAE1] text-black' : 'bg-white/5 text-slate-400'}`}><SettingsIcon size={20} /></button>
        </div>
        <div className="flex gap-2 p-1 bg-black/40 rounded-2xl border border-white/5">
           <button onClick={() => setViewMode('heatmap')} className={`flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase transition-all ${viewMode === 'heatmap' ? 'bg-[#27AAE1] text-black' : 'text-slate-500'}`}>Heatmap</button>
           <button onClick={() => setViewMode('points')} className={`flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase transition-all ${viewMode === 'points' ? 'bg-[#27AAE1] text-black' : 'text-slate-500'}`}>Vector Pins</button>
        </div>
      </div>
      <div className="flex-1 relative bg-black">
        <ZoomableFloorPlan floorPlanImage={mapImage}>
           <div className="absolute inset-0 pointer-events-none" style={{ mixBlendMode: 'multiply', opacity: viewMode === 'heatmap' ? 0.85 : 0 }}>
             <canvas ref={canvasRef} width={1000} height={1000} className="w-full h-full" />
           </div>
           {measurements.map((m, index) => (
            <div key={m.id} className="absolute" style={{ left: `${m.x * 100}%`, top: `${m.y * 100}%`, transform: 'translate(-50%, -50%)' }}>
               <div className={`w-5 h-5 rounded-full border border-white flex items-center justify-center text-[9px] font-black text-black ${viewMode === 'points' ? 'opacity-100' : 'opacity-0'}`} style={{ backgroundColor: getColorForValue(getMetricValue(m, selectedMetric), selectedMetric, settings.thresholds, settings.benchmarkMode, settings.rsrpTarget) }}>{index + 1}</div>
            </div>
          ))}
        </ZoomableFloorPlan>
      </div>
    </div>
  );
}
