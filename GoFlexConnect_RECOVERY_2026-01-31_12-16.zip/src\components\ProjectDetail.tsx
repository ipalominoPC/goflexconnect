import { useState, useEffect, useRef } from 'react';
import { ArrowLeft, FileDown, ShieldCheck, ChevronRight, ImagePlus, Loader2, FileText, Flame, FileSpreadsheet } from 'lucide-react';
import { useStore } from '../store/useStore';
import { exportToPDF, exportToCSV, generateMapSnapshot } from '../utils/calculations';
import { Share } from '@capacitor/share';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { supabase } from '../services/supabaseClient';

export default function ProjectDetail({ projectId, onBack, onStartSurvey, onViewHeatmap }: any) {
  const { projects, floors, setFloors, addFloor, measurements, settings } = useStore();
  const [isExporting, setIsExporting] = useState(false);
  const [showExportOptions, setShowExportOptions] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const project = projects.find((p: any) => p.id === projectId);
  const projectFloors = (floors || []).filter((f: any) => f.project_id === projectId || f.projectId === projectId);
  const siteMeasurements = (measurements || []).filter((m: any) => m.projectId === projectId);

  useEffect(() => {
    async function syncFloors() {
      const { data } = await supabase.from('floors').select('*').eq('project_id', projectId);
      if (data) setFloors(data);
    }
    if (projectId) syncFloors();
  }, [projectId]);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const reader = new FileReader();
    reader.onload = async () => {
      const base64Data = reader.result as string;
      const newFloor = {
        id: crypto.randomUUID(),
        project_id: projectId,
        name: file.name.split('.')[0].substring(0, 20) || 'Floor Plan',
        image_data: base64Data,
        created_at: new Date().toISOString()
      };
      try {
        addFloor(newFloor);
        await supabase.from('floors').insert([newFloor]);
      } catch (err) { console.error(err); } finally { setUploading(false); }
    };
    reader.readAsDataURL(file);
  };

  const handleExport = async (type: 'PDF' | 'CSV') => {
    setIsExporting(true);
    setShowExportOptions(false);
    try {
      const fileName = `GoFlexConnect_${project?.name || 'Site'}_${new Date().getTime()}.${type.toLowerCase()}`;
      let base64Data = "";
      if (type === 'CSV') {
        const csv = exportToCSV(siteMeasurements);
        base64Data = btoa(csv);
      } else {
        const floorImg = projectFloors[0]?.image_data;
        const snapshot = floorImg ? await generateMapSnapshot(floorImg, siteMeasurements, settings.benchmarkMode, settings.rsrpTarget) : null;
        const pdfBlob = await exportToPDF(siteMeasurements, project?.name || 'Site', snapshot, settings.benchmarkMode, settings.rsrpTarget);
        base64Data = await new Promise((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
          reader.readAsDataURL(pdfBlob);
        });
      }
      const savedFile = await Filesystem.writeFile({ path: fileName, data: base64Data, directory: Directory.Cache });
      await Share.share({ title: `GoFlexConnect ${type} Export`, url: savedFile.uri });
    } catch (err) { console.error(err); } finally { setIsExporting(false); }
  };

  if (!project) return <div className="p-20 text-white font-bold text-center">Site Offline</div>;

  return (
    <div className="min-h-screen bg-black text-white font-inter pb-40 relative z-[500] overflow-y-auto">
      <style>{`
        @keyframes landing-pulse { 0% { transform: scale(1); opacity: 0.3; } 50% { transform: scale(1.4); opacity: 0.5; } 100% { transform: scale(1); opacity: 0.3; } }
        @keyframes bar-pulse { 0%, 100% { transform: scaleY(0.8); opacity: 0.5; } 50% { transform: scaleY(1.15); opacity: 1; } }
      `}</style>
      <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileSelect} />
      <div className="bg-slate-900/95 border-b border-white/5 p-4 pt-14 flex items-center justify-between sticky top-0 z-[600] px-6">
        <button onClick={onBack} className="p-2 flex items-center gap-2 text-[#27AAE1] font-bold text-xs uppercase"><ArrowLeft size={20} /> Back</button>
        <ShieldCheck size={20} className="text-[#27AAE1]" />
      </div>
      <div className="p-6">
        <div className="flex flex-col items-center mb-10 relative">
          <div className="relative mb-6">
            <div className="absolute inset-0 bg-[#27AAE1] rounded-full animate-[landing-pulse_6s_infinite]" style={{ width: '80px', height: '80px', left: '50%', top: '50%', marginLeft: '-40px', marginTop: '-40px' }} />
            <div className="relative p-5 bg-black rounded-[2.5rem] border border-[#27AAE1]/30"><img src="/icons/logo-128.png" className="w-16 h-16 rounded-2xl" alt="GFC" /></div>
          </div>
          <h1 className="text-3xl font-black italic">GoFlexConnect</h1>
          <p className="text-xs font-bold text-[#27AAE1] tracking-widest uppercase">{project.name}</p>
        </div>
        <button onClick={() => projectFloors.length > 0 ? onStartSurvey(projectFloors[0].id) : fileInputRef.current?.click()} className="w-full py-8 border rounded-[2.2rem] mb-12 flex flex-col items-center gap-3 bg-slate-900 border-[#27AAE1]/40 shadow-xl">
          <div className="flex items-end gap-1.5 h-6">
             <div className="w-1.5 h-[35%] bg-red-500 rounded-full animate-[bar-pulse_2.5s_infinite_0.1s]" /><div className="w-1.5 h-[65%] bg-yellow-500 rounded-full animate-[bar-pulse_2.5s_infinite_0.3s]" /><div className="w-1.5 h-[100%] bg-green-500 rounded-full animate-[bar-pulse_2.5s_infinite_0.5s]" />
          </div>
          <span className="text-lg font-black text-white text-center">Start Site Survey</span>
        </button>
        <div className="space-y-6">
          <p className="text-[11px] text-[#27AAE1] font-black uppercase tracking-[0.6em] text-center">System Floor Plans</p>
          {projectFloors.map(floor => (
            <button key={floor.id} onClick={() => onStartSurvey(floor.id)} className="w-full p-5 bg-slate-900/60 border border-[#27AAE1]/20 rounded-[2.5rem] flex items-center justify-between shadow-xl">
              <div className="flex items-center gap-5">
                <div className="w-16 h-16 bg-black rounded-2xl border border-white/5 overflow-hidden"><img src={floor.image_data} className="w-full h-full object-cover opacity-80" alt="Map" /></div>
                <div className="text-left"><span className="font-black text-xl italic block text-white/95">{floor.name}</span><span className="text-[9px] font-bold text-[#27AAE1] uppercase tracking-[0.2em]">Deployment Ready</span></div>
              </div>
              <ChevronRight size={24} className="text-[#27AAE1] opacity-50" />
            </button>
          ))}
        </div>
        <div className="space-y-4 mt-16">
          <button onClick={onViewHeatmap} className="w-full py-8 bg-slate-900 border border-[#27AAE1]/40 rounded-[2.5rem] flex items-center justify-center gap-6 shadow-xl">
            <Flame className="w-8 h-8 text-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.5)]" />
            <div className="text-left"><p className="text-sm font-black uppercase tracking-widest text-white">View Heatmap</p><p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">RF Signal Coverage Map</p></div>
          </button>
          <div className="relative">
            <button onClick={() => setShowExportOptions(!showExportOptions)} className="w-full py-8 bg-slate-900 border border-white/10 rounded-[2.5rem] flex items-center justify-center gap-6 shadow-xl">
              {isExporting ? <Loader2 className="w-8 h-8 animate-spin text-[#27AAE1]" /> : <FileDown className="w-8 h-8 text-[#27AAE1]" />}
              <div className="text-left"><p className="text-sm font-black uppercase tracking-widest text-white">{isExporting ? 'Generating...' : 'Export Report'}</p><p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">PDF or CSV Format</p></div>
            </button>
            {showExportOptions && (
              <div className="absolute bottom-24 left-0 right-0 bg-slate-800 border border-white/10 rounded-3xl p-3 flex flex-col gap-2 z-[700] shadow-2xl">
                <button onClick={() => handleExport('PDF')} className="flex items-center justify-between p-5 bg-black/60 rounded-2xl hover:bg-[#27AAE1]/20"><span className="font-black text-xs uppercase text-white">Premium PDF Report</span><FileText className="text-red-500" /></button>
                <button onClick={() => handleExport('CSV')} className="flex items-center justify-between p-5 bg-black/60 rounded-2xl hover:bg-[#27AAE1]/20"><span className="font-black text-xs uppercase text-white">Data CSV Export</span><FileSpreadsheet className="text-green-500" /></button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
