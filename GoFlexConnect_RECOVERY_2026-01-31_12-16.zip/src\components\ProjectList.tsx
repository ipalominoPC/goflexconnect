﻿import { useState } from 'react';
import { Plus, Folder, ChevronRight, ArrowLeft, RefreshCw, Layout } from 'lucide-react';
import { useStore } from '../store/useStore';
import { supabase } from '../services/supabaseClient';

export default function ProjectList({ onCreateProject, onSelectProject, onBack }: any) {
  const projects = useStore((state) => state.projects);
  const setProjects = useStore((state) => state.setProjects);
  const setFloors = useStore((state) => state.setFloors);
  const setMeasurements = useStore((state) => state.setMeasurements);
  const [loading, setLoading] = useState(false);

  const forceLoadProjects = async () => {
    setLoading(true);
    try {
      const { data: pData, error: pError } = await supabase
        .from('projects')
        .select('*')
        .eq('user_id', '56cdb1f1-03c1-4a66-8f85-d3923c94ce6e')
        .order('created_at', { ascending: false });

      if (pError) throw pError;

      if (pData && pData.length > 0) {
        const projectIds = pData.map(p => p.id);

        const { data: fData, error: fError } = await supabase
          .from('floors')
          .select('*')
          .in('project_id', projectIds);
        if (fError) throw fError;

        const { data: mData, error: mError } = await supabase
          .from('measurements')
          .select('*')
          .in('project_id', projectIds);
        if (mError) throw mError;

        // Senior Fix: Ensure DB snake_case maps to Store camelCase
        const mappedMeasurements = (mData || []).map(m => ({
          ...m,
          projectId: m.project_id,
          floorId: m.floor_id,
          cellId: m.cell_id,
          carrierName: m.carrier_name,
          techType: m.tech_type
        }));

        setProjects(pData);
        setFloors(fData || []);
        setMeasurements(mappedMeasurements);

        alert(`✅ Mission Control Synced:\n${pData.length} Sites\n${fData?.length} Floorplans\n${mappedMeasurements.length} Signal Records`);
      }
    } catch (err: any) {
      alert('❌ Deep Sync Failed: ' + err.message);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-black text-white font-inter pb-40">
      <style>{`
        @keyframes landing-pulse {
          0% { transform: scale(1); opacity: 0.3; filter: blur(15px); }
          50% { transform: scale(1.4); opacity: 0.6; filter: blur(30px); }
          100% { transform: scale(1); opacity: 0.3; filter: blur(15px); }
        }
      `}</style>
      <div className="fixed top-0 left-0 right-0 h-48 bg-black/90 backdrop-blur-3xl border-b border-white/5 z-[100] px-6 pt-20">
        <div className="flex items-start justify-between mb-6">
           <button onClick={onBack} className="p-3 bg-white/5 rounded-2xl text-[#27AAE1] active:scale-90 transition-all border border-white/10">
            <ArrowLeft size={24} strokeWidth={3} />
          </button>
          <button onClick={forceLoadProjects} disabled={loading} className="flex items-center gap-2 bg-slate-900 border border-[#27AAE1]/30 text-[#27AAE1] px-4 py-2 rounded-xl font-black text-[10px] tracking-widest active:scale-95 transition-all shadow-[0_0_15px_rgba(39,170,225,0.1)]">
            <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
            RESTORE DATA
          </button>
        </div>
        <div className="flex items-center gap-6">
          <div className="relative flex items-center justify-center w-16 h-16">
            <div className="absolute inset-0 bg-[#27AAE1] rounded-full animate-[landing-pulse_4s_infinite]" />
            <img src="/icons/logo-128.png" alt="Cloud" className="relative w-16 h-16 rounded-2xl border border-[#27AAE1]/40 shadow-[0_0_20px_rgba(39,170,225,0.4)]" />
          </div>
          <div className="flex flex-col">
            <h1 className="text-3xl font-black tracking-tighter italic leading-none">GoFlexConnect</h1>
            <p className="text-[11px] text-[#27AAE1] font-black uppercase tracking-[0.4em] mt-2">Command Center</p>
          </div>
        </div>
      </div>
      <div className="p-6 mt-56">
        <div className="mb-12">
          <button onClick={onCreateProject} className="w-full bg-slate-900/50 border border-[#27AAE1]/30 rounded-[2.5rem] p-8 flex items-center justify-between group active:scale-[0.98] transition-all shadow-[0_0_30px_rgba(39,170,225,0.1)]">
            <div className="flex items-center gap-6">
              <div className="p-5 bg-[#27AAE1]/10 rounded-3xl border border-[#27AAE1]/20 shadow-[0_0_20px_rgba(39,170,225,0.2)]">
                <Plus size={32} className="text-[#27AAE1]" strokeWidth={4} />
              </div>
              <div className="text-left">
                <p className="text-2xl font-black text-white uppercase tracking-tight">Deploy New Site</p>
                <p className="text-xs font-bold text-[#27AAE1] uppercase tracking-widest mt-1 opacity-60">Initialize Field Project</p>
              </div>
            </div>
            <Layout size={28} className="text-slate-800 group-hover:text-[#27AAE1]" />
          </button>
        </div>
        <div className="space-y-6">
          <p className="px-4 text-[10px] text-slate-500 font-black uppercase tracking-[0.4em] text-center">Verified Field Projects</p>
          {projects.map((project) => (
            <button key={project.id} onClick={() => onSelectProject(project.id)} className="w-full bg-slate-900/30 border border-white/5 rounded-[2.2rem] p-7 flex items-center justify-between group active:bg-white/5 transition-all shadow-xl hover:border-[#27AAE1]/30">
              <div className="flex items-center gap-6">
                <div className="w-16 h-16 bg-black rounded-2xl flex items-center justify-center border border-[#27AAE1]/30 shadow-[0_0_20px_rgba(39,170,225,0.15)]">
                  <Folder size={28} className="text-[#27AAE1] drop-shadow-[0_0_8px_rgba(39,170,225,0.8)]" />
                </div>
                <div className="text-left">
                  <p className="text-xl font-black text-white tracking-tight">{project.name}</p>
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">{project.location || 'SITE_ACTIVE'}</p>
                </div>
              </div>
              <ChevronRight size={24} className="text-slate-800 group-hover:text-[#27AAE1]" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
