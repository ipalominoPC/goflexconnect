import { Radio, MapPin, FolderKanban, Shield } from 'lucide-react';

interface LandingProps {
  onGetAccess: () => void;
  onLogIn: () => void;
}

export function Landing({ onGetAccess, onLogIn }: LandingProps) {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-[#27AAE1]/30">
      {/* NAVBAR - POSITIONED LOWER (pt-6) & MIXED CASE */}
      <nav className="sticky top-0 z-50 bg-black/80 backdrop-blur-md border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 h-20 pt-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img src="/icons/logo-96.png" className="h-9 w-9 rounded-xl border border-[#27AAE1]/30 shadow-[0_0_15px_rgba(39,170,225,0.6)]" />
            <span className="text-xl font-bold tracking-tighter text-white">GoFlexConnect</span>
          </div>
          <div className="hidden md:flex items-center space-x-8">
            <button onClick={() => scrollToSection('features')} className="text-gray-400 hover:text-white text-xs font-bold uppercase transition-colors">Features</button>
            <button onClick={onLogIn} className="text-gray-400 hover:text-white text-xs font-bold uppercase transition-colors">Log In</button>
            <button onClick={onGetAccess} className="bg-gradient-to-r from-[#27AAE1] to-[#1d8bb8] px-4 py-2 rounded-lg text-[10px] font-black normal-case tracking-normal shadow-[0_0_20px_rgba(39,170,225,0.4)] border border-[#27AAE1]/30">Get Access</button>
          </div>
        </div>
      </nav>

      {/* HERO SECTION - CENTERED LOGO & TITLE */}
      <section id="hero" className="py-20 px-6">
        <div className="max-w-7xl mx-auto flex flex-col items-center text-center">
          
          {/* CENTERED CLOUD LOGO - PULSING GLOW */}
          <div className="relative mb-10">
            <div className="absolute inset-0 bg-[#27AAE1] blur-[50px] opacity-40 rounded-full animate-pulse"></div>
            <img
              src="/icons/logo-128.png"
              alt="GFC Cloud"
              className="relative w-32 h-32 rounded-[32px] shadow-[0_0_40px_rgba(39,170,225,0.6)] border-2 border-[#27AAE1]/40"
            />
          </div>

          <div className="max-w-4xl space-y-6">
            <h1 className="text-3xl md:text-5xl font-black tracking-tighter leading-tight text-white mb-6">
              Cellular Signal Survey <br/>
              <span className="text-[#27AAE1] drop-shadow-[0_0_15px_rgba(39,170,225,0.4)]">& Analysis Tool</span>
            </h1>
            
            <p className="max-w-2xl mx-auto text-slate-400 text-lg leading-relaxed font-medium mb-10">
              Professional 4G and 5G signal surveying for RF engineers. Create detailed heatmaps, 
              analyze network performance, and optimize coverage with real-time hardware data.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center w-full max-w-md mx-auto">
              <button onClick={onGetAccess} className="flex-1 bg-gradient-to-r from-[#27AAE1] to-[#1d8bb8] px-8 py-4 rounded-2xl text-sm font-black normal-case tracking-normal shadow-[0_0_25px_rgba(39,170,225,0.5)] border border-[#27AAE1]/30 active:scale-95 transition-all">Get Free Access</button>
              <button onClick={onLogIn} className="flex-1 bg-slate-900 border border-white/10 px-8 py-4 rounded-2xl text-sm font-black normal-case tracking-normal hover:bg-slate-800 transition-all">Log In</button>
            </div>
          </div>
        </div>
      </section>

      {/* NEON FEATURE GRID - RE-ADDED GLOWS */}
      <section id="features" className="py-24 bg-slate-900/20 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-xl font-bold normal-case tracking-[0.4em] text-slate-200 mb-16">Powerful Features</h2>
          <div className="grid md:grid-cols-3 gap-12 text-left">
            <div className="p-10 bg-slate-900 border border-[#27AAE1]/20 rounded-[2.5rem] shadow-[0_0_30px_rgba(39,170,225,0.15)] hover:shadow-[0_0_35px_rgba(39,170,225,0.3)] transition-all group">
              <Radio className="w-10 h-10 text-[#27AAE1] mb-6 drop-shadow-[0_0_8px_rgba(39,170,225,0.6)]" />
              <h3 className="text-lg font-bold uppercase mb-3 tracking-widest text-white">Signal Scanning</h3>
              <p className="text-slate-500 text-sm leading-relaxed">Capture hardware-direct RSRP, RSRQ, and SINR data.</p>
            </div>
            <div className="p-10 bg-slate-900 border border-green-500/20 rounded-[2.5rem] shadow-[0_0_30px_rgba(34,197,94,0.15)] hover:shadow-[0_0_35px_rgba(34,197,94,0.3)] transition-all group">
              <MapPin className="w-10 h-10 text-green-500 mb-6 drop-shadow-[0_0_8px_rgba(34,197,94,0.6)]" />
              <h3 className="text-lg font-bold uppercase mb-3 tracking-widest text-white">Live Heatmaps</h3>
              <p className="text-slate-500 text-sm leading-relaxed">Instant coverage visualization using Peak Signal Engine.</p>
            </div>
            <div className="p-10 bg-slate-900 border border-orange-500/20 rounded-[2.5rem] shadow-[0_0_30px_rgba(249,115,22,0.15)] hover:shadow-[0_0_35px_rgba(249,115,22,0.3)] transition-all group">
              <FolderKanban className="w-10 h-10 text-orange-500 mb-6 drop-shadow-[0_0_8px_rgba(249,115,22,0.6)]" />
              <h3 className="text-lg font-bold uppercase mb-3 tracking-widest text-white">Project Vault</h3>
              <p className="text-slate-500 text-sm leading-relaxed">Securely organize surveys with automated cloud sync.</p>
            </div>
          </div>
        </div>
      </section>

      {/* STRATEGIC PARTNER BOX */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="bg-slate-900/40 border-2 border-dashed border-[#27AAE1]/30 rounded-[3rem] p-12 text-center shadow-[0_0_50px_rgba(39,170,225,0.1)]">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-[#27AAE1]/10 border border-[#27AAE1]/20 mb-8 shadow-[0_0_20px_rgba(39,170,225,0.4)]">
               <Shield className="w-10 h-10 text-[#27AAE1] animate-pulse" />
            </div>
            <h2 className="text-xl font-bold normal-case tracking-[0.4em] text-white mb-4">Strategic Partnership</h2>
            <p className="text-slate-400 text-sm leading-relaxed">Certified hardware monitoring for professional DAS deployments.</p>
            <div className="mt-10 pt-10 border-t border-white/5">
               <span className="text-[10px] font-bold normal-case tracking-[0.6em] text-slate-700">Authorized Infrastructure Partner</span>
            </div>
          </div>
        </div>
      </section>

      <footer className="py-12 border-t border-white/5 text-center">
        <p className="text-[10px] font-black text-slate-700 uppercase tracking-[0.5em]">� 2026 GoFlexConnect. All rights reserved.</p>
      </footer>
    </div>
  );
}
