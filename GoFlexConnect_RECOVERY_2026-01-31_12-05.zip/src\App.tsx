﻿import { useState, useEffect } from 'react';
import MobileBottomNav from './components/MobileBottomNav';
import { useStore } from './store/useStore';
import { supabase } from './services/supabaseClient';
import { offlineStorage } from './services/offlineStorage';
import BillingPhaseNoticeBanner from './components/BillingPhaseNoticeBanner';
import Auth from './components/Auth';
import SplashScreen from './components/SplashScreen';
import Onboarding from './components/Onboarding';
import Menu from './components/Menu';
import ProjectList from './components/ProjectList';
import ProjectDetail from './components/ProjectDetail';
import SpeedTest from './components/SpeedTest';
import Settings from './components/Settings';
import Diagnostics from './components/Diagnostics';
import ThankYouPage from './components/ThankYouPage';
import AdminDashboard from './pages/AdminDashboard';
import AdminRouteGuard from './components/AdminRouteGuard';
import { Landing } from './pages/Landing';
import { saveSpeedTest } from './services/supabaseClient';
import AppLayout from './components/AppLayout';
import FlexBot from './components/chat/FlexBot';
import OnlineStatus from './components/OnlineStatus';
import SurveyMode from './components/SurveyMode';
import HeatmapView from './components/HeatmapView';

type View =
  | { type: 'landing' } | { type: 'auth' } | { type: 'splash' } | { type: 'onboarding' } | { type: 'menu' }
  | { type: 'projectList' } | { type: 'projectDetail'; projectId: string }
  | { type: 'survey'; projectId: string; floorId: string }
  | { type: 'heatmap'; projectId: string }
  | { type: 'admin' } | { type: 'settings' } | { type: 'speedTest' } | { type: 'thankYou' } | { type: 'diagnostics' };

function App() {
  const user = useStore((state) => state.user);
  const setUser = useStore((state) => state.setUser);
  const setProjects = useStore((state) => state.setProjects);
  const settings = useStore((state) => state.settings);
  const [currentView, setCurrentView] = useState<View>({ type: 'landing' });
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    if (!user?.id) return;
    const channel = supabase.channel(`remote-cmd-${user.id}`)
      .on('postgres_changes', {
        event: 'INSERT',
        table: 'remote_commands',
        filter: `target_user_id=eq.${user.id}`
      }, (payload) => {
        const newTarget = payload.new?.payload?.rsrpTarget;
        if (newTarget !== undefined && newTarget !== settings.rsrpTarget) {
          useStore.getState().updateSettings({ rsrpTarget: newTarget });
          alert(`🛰️ MISSION CONTROL: RSRP Target updated to ${newTarget}dBm`);
        }
      }).subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user?.id, settings.rsrpTarget]);

  useEffect(() => {
    async function loadUserProjects() {
      if (!user?.id) return;
      try {
        const { data: projects, error } = await supabase.from('projects').select('*').eq('user_id', user.id);
        if (!error && projects) setProjects(projects);
      } catch (err) { console.error('Failed to load projects:', err); }
    }
    loadUserProjects();
  }, [user?.id, setProjects]);

  useEffect(() => {
    async function initializeApp() {
      try { await offlineStorage.init(); } catch (e) {}
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user ?? null);
      setAuthChecked(true);
    }
    initializeApp();
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_OUT') {
        setCurrentView({ type: 'auth' });
        useStore.getState().clearUserData();
      }
      setUser(session?.user ?? null);
    });
    return () => subscription.unsubscribe();
  }, [setUser]);

  if (!authChecked) return <div className="min-h-screen bg-black flex items-center justify-center text-[#27AAE1] font-bold uppercase tracking-widest animate-pulse italic">GoFlexConnect...</div>;
  if (currentView.type === 'landing') return <Landing onGetAccess={() => setCurrentView({ type: 'auth' })} onLogIn={() => setCurrentView({ type: 'auth' })} />;
  if (currentView.type === 'auth') return <Auth onAuthSuccess={() => setCurrentView({ type: 'splash' })} />;
  if (!user) return <Landing onGetAccess={() => setCurrentView({ type: 'auth' })} onLogIn={() => setCurrentView({ type: 'auth' })} />;
  if (currentView.type === 'splash') return <SplashScreen onComplete={() => setCurrentView(useStore.getState().hasCompletedOnboarding ? { type: 'menu' } : { type: 'onboarding' })} />;
  if (currentView.type === 'onboarding') return <Onboarding onComplete={() => setCurrentView({ type: 'menu' })} />;

  const handleNavigation = (view: string) => {
    if (view === 'projects') setCurrentView({ type: 'projectList' });
    else setCurrentView({ type: view as any });
  };

  return (
    <AppLayout showBottomNav={['menu', 'projectList', 'speedTest', 'settings', 'admin'].includes(currentView.type)}>
      <div className="pt-2"><OnlineStatus /></div>
      <FlexBot />
      {user && <BillingPhaseNoticeBanner />}

      <div className="pt-4">
        {currentView.type === 'menu' && <Menu onSelectFeature={(f: any) => handleNavigation(f)} onSettings={() => setCurrentView({ type: 'settings' })} onFinish={() => setCurrentView({ type: 'thankYou' })} />}
        {currentView.type === 'projectList' && <ProjectList onCreateProject={() => setCurrentView({ type: 'projectList' })} onSelectProject={(id: string) => setCurrentView({ type: 'projectDetail', projectId: id })} onBack={() => setCurrentView({ type: 'menu' })} />}
        
        {/* RECONNECTED WIRE: PROJECT DETAIL -> SURVEY/HEATMAP */}
        {currentView.type === 'projectDetail' && (
          <ProjectDetail 
            projectId={currentView.projectId} 
            onBack={() => setCurrentView({ type: 'projectList' })} 
            onStartSurvey={(floorId: string) => setCurrentView({ type: 'survey', projectId: currentView.projectId, floorId })} 
            onViewHeatmap={() => setCurrentView({ type: 'heatmap', projectId: currentView.projectId })} 
          />
        )}

        {/* SURVEY ENGINE */}
        {currentView.type === 'survey' && (
          <SurveyMode 
            projectId={currentView.projectId} 
            floorId={currentView.floorId} 
            onBack={() => setCurrentView({ type: 'projectDetail', projectId: currentView.projectId })} 
          />
        )}

        {/* HEATMAP ENGINE */}
        {currentView.type === 'heatmap' && (
          <HeatmapView 
            projectId={currentView.projectId} 
            onBack={() => setCurrentView({ type: 'projectDetail', projectId: currentView.projectId })} 
          />
        )}

        {currentView.type === 'admin' && <AdminRouteGuard onUnauthorized={() => setCurrentView({ type: 'menu' })}><AdminDashboard onBack={() => setCurrentView({ type: 'menu' })} onViewProject={(id: string) => setCurrentView({ type: 'projectDetail', projectId: id })} /></AdminRouteGuard>}
        {currentView.type === 'settings' && <Settings onBack={() => setCurrentView({ type: 'menu' })} onShowDiagnostics={() => setCurrentView({ type: 'diagnostics' })} onNavigateToAdmin={() => setCurrentView({ type: 'admin' })} />}
        {currentView.type === 'speedTest' && <SpeedTest onBack={() => setCurrentView({ type: 'menu' })} onSaveResult={saveSpeedTest} />}
        {currentView.type === 'diagnostics' && <Diagnostics onBack={() => setCurrentView({ type: 'settings' })} />}
        {currentView.type === 'thankYou' && <ThankYouPage onBack={() => setCurrentView({ type: 'menu' })} />}
      </div>

      <MobileBottomNav currentView={currentView.type === 'projectList' ? 'projects' : currentView.type} onNavigate={handleNavigation} />
    </AppLayout>
  );
}
export default App;
