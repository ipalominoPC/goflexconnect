﻿import { useState, useEffect, useRef } from 'react';
import { Send, X } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { supabase } from '../../services/supabaseClient';
import './FlexBot.css';

export default function FlexBot() {
  const { user, projects, currentProjectId, measurements, settings } = useStore();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<any[]>([{ role: 'assistant', content: 'Hello. I am Flexbot. I have established a link to your S24 hardware. How can I help?' }]);
  const [input, setInput] = useState('');
  const [status, setStatus] = useState<'idle' | 'thinking' | 'speaking'>('idle');
  const [transcriptId, setTranscriptId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => { if (isOpen) messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim() || status === 'thinking') return;
    
    const latestMeasure = measurements[measurements.length - 1];
    const telemetryContext = latestMeasure ? {
      carrier: latestMeasure.carrier_name,
      tech: latestMeasure.tech_type,
      rsrp: latestMeasure.rsrp,
      rsrq: latestMeasure.rsrq,
      sinr: latestMeasure.sinr,
      cellId: latestMeasure.cell_id,
      rsrpTarget: settings.rsrpTarget
    } : null;

    const userMsg = { role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setStatus('thinking');

    try {
      if (!transcriptId && user) {
        const { data } = await supabase.from('chat_transcripts').insert({
          user_id: user.id, user_email: user.email, messages: [...messages, userMsg],
          metadata: { 
            projectId: currentProjectId, 
            projectName: projects.find(p => p.id === currentProjectId)?.name,
            telemetryAtStart: telemetryContext 
          }
        }).select().single();
        if (data) setTranscriptId(data.id);
      }

      // INJECTING TELEMETRY INTO THE BRAIN
      const { data, error } = await supabase.functions.invoke('flexbot-brain', { 
        body: { 
          messages: [...messages, userMsg],
          telemetry: telemetryContext 
        } 
      });

      const botReply = error ? "System busy. Please try again." : data.reply;
      const finalMessages = [...messages, userMsg, { role: 'assistant', content: botReply }];
      
      setMessages(finalMessages);
      setStatus('speaking');

      if (transcriptId) {
        await supabase.from('chat_transcripts').update({ 
          messages: finalMessages, 
          updated_at: new Date().toISOString() 
        }).eq('id', transcriptId);
      }
      
      setTimeout(() => setStatus('idle'), 1000);
    } catch (e) { 
      setStatus('idle'); 
    }
  };

  return (
    <div className="fixed bottom-24 right-6 z-[100] font-inter">
      <style>{`
        @keyframes fb-blink { 0%, 48%, 52%, 100% { transform: scaleY(1); } 50% { transform: scaleY(0.1); } }
        @keyframes fb-drift { 0%, 100% { transform: translate(0, 0); } 33% { transform: translate(2px, -2px); } 66% { transform: translate(-2px, 1px); } }
      `}</style>
      {!isOpen && (
        <button onClick={() => setIsOpen(true)} className="flex items-center gap-4 bg-black/80 backdrop-blur-2xl border border-white/10 px-6 py-4 rounded-full shadow-[0_0_30px_rgba(0,0,0,0.5)] active:scale-95 group">
          <div className="relative">
            <div className="absolute inset-0 bg-[#27AAE1] blur-xl opacity-40 animate-pulse scale-150" />
            <img src="/chatpill.svg" className="w-7 h-7 relative z-10" alt="Assistant" />
          </div>
          <span className="text-[12px] font-bold text-white/90">Flexbot Intelligence</span>
        </button>
      )}
      {isOpen && (
        <div className="w-[340px] h-[540px] bg-black border border-white/10 rounded-[2.8rem] shadow-[0_0_60px_rgba(0,0,0,1)] flex flex-col overflow-hidden animate-in zoom-in-95">
          <div className="p-7 bg-white/5 border-b border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-4">
               <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-[#27AAE1]/30 bg-black">
                <img src="/flexbot/avatar-face.png" className="w-full h-full object-cover" style={{ animation: 'fb-blink 4s infinite, fb-drift 8s infinite ease-in-out' }} alt="Flexbot" />
               </div>
               <div>
                <p className="text-sm font-black text-white">Assistant</p>
                <div className="flex items-center gap-1.5">
                  <div className="w-1 h-1 bg-[#27AAE1] rounded-full animate-pulse" />
                  <p className="text-[9px] text-[#27AAE1] font-bold uppercase tracking-widest">Telemetry Link Active</p>
                </div>
               </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="p-2 text-slate-500 hover:text-white"><X size={20} /></button>
          </div>
          <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-hide">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] px-5 py-3.5 rounded-[1.4rem] text-[13px] shadow-lg ${m.role === 'user' ? 'bg-[#27AAE1] text-white font-medium' : 'bg-white/10 text-slate-200 border border-white/5'}`}>{m.content}</div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
          <div className="p-5 bg-white/5 border-t border-white/5 flex gap-3">
            <input type="text" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSend()} className="flex-1 bg-black border border-white/10 rounded-2xl px-5 py-3.5 text-[13px] text-white outline-none focus:border-[#27AAE1]/40 shadow-[inset_0_0_10px_rgba(39,170,225,0.05)]" placeholder="Ask about your signal..." />
            <button onClick={handleSend} className="bg-white text-black p-3.5 rounded-2xl active:scale-90 shadow-lg hover:bg-[#27AAE1] hover:text-white transition-colors"><Send size={20} /></button>
          </div>
        </div>
      )}
    </div>
  );
}
