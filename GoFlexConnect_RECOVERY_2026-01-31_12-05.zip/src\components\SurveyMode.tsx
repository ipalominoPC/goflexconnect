﻿import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Crosshair, Wifi, Radio as RadioIcon, Trash2, Database, AlertTriangle } from 'lucide-react';
import { useStore } from '../store/useStore';
import { getCellularSignal, watchCellularSignal, clearSignalWatch } from '../services/cellularSignalService';
import { getCurrentLocation, requestLocationPermissions } from '../services/deviceService';
import { Measurement } from '../types';
import ZoomableFloorPlan from './ZoomableFloorPlan';
import { generateUUID } from '../utils/uuid';
import { getSignalQuality } from '../utils/qualityUtils';

const RFSparkline = ({ data, color, min, max }: { data: number[], color: string, min: number, max: number }) => {
  if (!data || data.length < 2) return <div className="h-4 w-full bg-slate-800/20 rounded mt-1" />;
  const width = 100;
  const height = 20;
  const points = data.map((val, i) => {
    const x = (i / (data.length - 1)) * width;
    const normalized = Math.min(Math.max((val - min) / (max - min), 0), 1);
    const y = height - (normalized * height);
    return `${x},${y}`;
  }).join(' ');
  return (
    <div className="h-6 w-full opacity-90 mt-1">
      <svg viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" className="w-full h-full overflow-visible">
        <polyline fill="none" stroke={color} strokeWidth="1.5" points={points} />
      </svg>
    </div>
  );
};

export default function SurveyMode({ projectId, floorId, onBack }: any) {
  const { projects, floors, measurements: allMs, addMeasurement, deleteMeasurement, settings } = useStore();
  
  const project = projects.find((p) => p.id === projectId);
  const floor = floors.find((f) => f.id === floorId);
  const mapImage = floor?.image_data || floor?.floorPlanImage || project?.floorPlanImage;

  const measurements = (allMs || []).filter((m) => (m.floorId === floorId || m.floor_id === floorId) && m.projectId === projectId);

  const [cursorPosition, setCursorPosition] = useState({ x: 0.5, y: 0.5 });
  const [isCapturing, setIsCapturing] = useState(false);
  const [activeCarrier, setActiveCarrier] = useState<'T-Mobile' | 'Verizon' | 'AT&T'>('T-Mobile');
  const [liveSignal, setLiveSignal] = useState<any>(null);
  const [signalHistory, setSignalHistory] = useState<{rsrp: number[], rsrq: number[], snr: number[]}>({ rsrp: [], rsrq: [], snr: [] });
  const [isMapLoaded, setIsMapLoaded] = useState(false);

  useEffect(() => {
    requestLocationPermissions();
    const sigId = watchCellularSignal((s: any) => setLiveSignal(s), 1000);
    return () => { if (sigId) clearSignalWatch(sigId); };
  }, []);

  useEffect(() => {
    if (liveSignal) {
      setSignalHistory(prev => ({
        rsrp: [...(prev.rsrp || []), Number(liveSignal.rsrp) || -140].slice(-30),
        rsrq: [...(prev.rsrq || []), Number(liveSignal.rsrq) || -20].slice(-30),
        snr: [...(prev.snr || []), Number(liveSignal.sinr) || -10].slice(-30),
      }));
    }
  }, [liveSignal]);

  if (!project || !floor) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-10 text-center">
        <AlertTriangle size={64} className="text-red-500 mb-4 animate-pulse" />
        <h2 className="text-xl font-black text-white uppercase mb-2">Data Link Severed</h2>
        <button onClick={onBack} className="w-full py-4 bg-[#27AAE1] text-black font-black rounded-2xl uppercase">Return to Mission Control</button>
      </div>
    );
  }

  const handleCaptureSample = async () => {
    if (!mapImage) return;
    setIsCapturing(true);
    try {
      const signalData = liveSignal || { rsrp: -140, rsrq: -20, sinr: -10 };
      const measurement: Measurement = {
        id: generateUUID(),
        projectId,
        floorId: floorId || '',
        x: Math.max(0.01, Math.min(0.99, cursorPosition.x)),
        y: Math.max(0.01, Math.min(0.99, cursorPosition.y)),
        locationNumber: measurements.length + 1,
        rsrp: Number(signalData.rsrp) || -140,
        rsrq: Number(signalData.rsrq) || -20,
        sinr: Number(signalData.sinr) || -10,
        carrierName: activeCarrier,
        timestamp: Date.now(),
      };
      addMeasurement(measurement);
    } catch (e) { console.error("Capture failed", e); }
    setTimeout(() => setIsCapturing(false), 300);
  };

  return (
    <div className="fixed inset-0 bg-black flex flex-col overflow-hidden text-white z-[1000]">
      {/* HEADER */}
      <div className="shrink-0 bg-slate-900/95 border-b border-white/5 pt-12 pb-3 px-4 z-30 shadow-2xl">
        <div className="flex items-center justify-between mb-2">
          <button onClick={onBack} className="p-2 text-[#27AAE1] active:opacity-50"><ArrowLeft size={24} /></button>
          <div className="flex bg-black/40 p-1 rounded-lg border border-white/5 gap-1">
            {['T-Mobile', 'Verizon', 'AT&T'].map((c) => (
              <button key={c} onClick={() => setActiveCarrier(c as any)}
                className={`px-3 py-1 rounded-md text-[9px] font-black transition-all ${activeCarrier === c ? (c === 'T-Mobile' ? 'bg-[#E20074]' : c === 'Verizon' ? 'bg-red-600' : 'bg-blue-500') : 'text-slate-500 opacity-40'}`}>
                {c.toUpperCase()}
              </button>
            ))}
          </div>
          <button onClick={() => measurements.length > 0 && deleteMeasurement(measurements[measurements.length-1].id)} className="p-2 text-red-500 active:scale-90"><Trash2 size={20} /></button>
        </div>

        <div className="bg-black/60 rounded-xl border border-[#27AAE1]/20 p-3">
          <div className="grid grid-cols-3 gap-2">
            <div className="flex flex-col items-center"><span className="text-[8px] text-slate-500 font-bold uppercase">RSRP</span><span className="text-sm font-black">{liveSignal?.rsrp || "--"}</span><RFSparkline data={signalHistory.rsrp} color="#27AAE1" min={-140} max={-44} /></div>
            <div className="flex flex-col items-center"><span className="text-[8px] text-slate-500 font-bold uppercase">SNR</span><span className="text-sm font-black">{liveSignal?.sinr || "--"}</span><RFSparkline data={signalHistory.snr} color="#27AAE1" min={-10} max={30} /></div>
            <div className="flex flex-col items-center"><span className="text-[8px] text-slate-500 font-bold uppercase">RSRQ</span><span className="text-sm font-black">{liveSignal?.rsrq || "--"}</span><RFSparkline data={signalHistory.rsrq} color="#27AAE1" min={-20} max={-3} /></div>
          </div>
        </div>
      </div>

      {/* VIEWPORT */}
      <div className="flex-1 relative bg-black">
        <ZoomableFloorPlan 
          floorPlanImage={mapImage} 
          allowClick={true} 
          onCanvasClick={(x,y) => setCursorPosition({x, y})}
          onLoad={() => setIsMapLoaded(true)}
        >
           {/* PIN RENDER GUARD: Only render if map is loaded and data is safe */}
           {isMapLoaded && measurements.map((m, index) => {
            try {
              const quality = getSignalQuality(m, settings?.thresholds || { rsrp: { good: -90, fair: -110 }, sinr: { good: 10, fair: 0 } });
              return (
                <div key={m.id} className="absolute" style={{ left: `${m.x * 100}%`, top: `${m.y * 100}%`, transform: 'translate(-50%, -50%)' }}>
                   <div className={`w-3.5 h-3.5 rounded-full border-[0.5px] border-white/50 shadow-sm flex items-center justify-center text-[6px] font-black text-black ${quality.bgColor}`}>
                      {index + 1}
                   </div>
                </div>
              );
            } catch (e) { return null; }
          })}
          
          <div className="absolute" style={{ left: `${cursorPosition.x * 100}%`, top: `${cursorPosition.y * 100}%`, transform: 'translate(-50%, -50%)' }}>
             <Crosshair className="w-5 h-5 text-[#27AAE1] drop-shadow-[0_0_8px_#27AAE1]" strokeWidth={2} />
          </div>
        </ZoomableFloorPlan>

        <div className="absolute top-6 left-6 p-3 bg-black/80 backdrop-blur-md rounded-2xl border border-[#27AAE1]/30 shadow-2xl z-40">
           <div className="flex items-center gap-2">
             <Database size={14} className="text-[#27AAE1]" />
             <span className="text-xs font-black text-white">{measurements.length} <span className="text-[#27AAE1] opacity-60 uppercase">Captures</span></span>
           </div>
        </div>
      </div>

      {/* CAPTURE BUTTON */}
      <div className="shrink-0 p-4 bg-slate-900 border-t border-white/5 pb-12">
        <button onClick={handleCaptureSample} disabled={isCapturing || !mapImage} className="w-full py-5 bg-[#27AAE1] text-black rounded-[1.5rem] font-black text-lg active:scale-[0.98] transition-all">
          {isCapturing ? 'RECORDING...' : 'CAPTURE SITE DATA'}
        </button>
      </div>
    </div>
  );
}
