import { useState, useEffect } from 'react';
import { Mail, Lock, Eye, EyeOff, Loader2 } from 'lucide-react';
import { supabase } from '../services/supabaseClient';
import { useStore } from '../store/useStore';

interface AuthProps {
  onAuthSuccess: () => void;
  initialMode?: 'login' | 'signup';
}

export default function Auth({ onAuthSuccess, initialMode = 'login' }: AuthProps) {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSignUp, setIsSignUp] = useState(initialMode === 'signup');
  const [error, setError] = useState<string | null>(null);
  const setUser = useStore((state) => state.setUser);

  useEffect(() => {
    setIsSignUp(initialMode === 'signup');
  }, [initialMode]);

  async function handleAuth(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const { data, error } = isSignUp
        ? await supabase.auth.signUp({ email, password })
        : await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      if (data.user) {
        setUser(data.user);
        onAuthSuccess();
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 text-white font-sans relative overflow-hidden">
      <div className="w-full max-w-md">
        <div className="flex flex-col items-center mb-12 text-center">
          
          {/* THE CLOUD SOUL - SYNCED 1:1 FROM LANDING.TSX */}
          <div className="relative mb-10">
            <div className="absolute inset-0 bg-[#27AAE1] blur-[50px] opacity-40 rounded-full animate-pulse"></div>
            <img
              src="/icons/logo-128.png"
              alt="GoFlexConnect"
              className="relative w-32 h-32 rounded-[32px] shadow-[0_0_40px_rgba(39,170,225,0.6)] border-2 border-[#27AAE1]/40"
            />
          </div>

          <h1 className="text-3xl font-bold text-white mb-2 force-mixed-case">
            GoFlexConnect
          </h1>
          <p className="text-slate-400 text-sm font-medium" style={{ textTransform: 'none !important' }}>
            Professional Signal Surveying
          </p>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-400 text-xs p-3 rounded-lg mb-6 text-center">
            {error}
          </div>
        )}

        <form onSubmit={handleAuth} className="space-y-5">
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
            <input
              type="email"
              autoComplete="username"
              className="w-full bg-slate-900 border border-white/10 rounded-2xl pl-12 pr-4 py-4 outline-none focus:ring-2 focus:ring-[#27AAE1] transition-all text-white"
              placeholder="Email Address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
            <input
              type={showPassword ? "text" : "password"}
              autoComplete="current-password"
              className="w-full bg-slate-900 border border-white/10 rounded-2xl pl-12 pr-4 py-4 outline-none focus:ring-2 focus:ring-[#27AAE1] transition-all text-white"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-[#27AAE1]"
            >
              {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-[#27AAE1] to-[#1d8bb8] text-white py-4 rounded-xl font-black text-sm normal-case tracking-wide hover:shadow-[0_0_30px_rgba(39,170,225,0.6)] transition-all active:scale-95 shadow-[0_0_20px_rgba(39,170,225,0.4)] border border-[#27AAE1]/30 flex items-center justify-center gap-2"
          >
            {loading ? <Loader2 className="animate-spin w-5 h-5" /> : (isSignUp ? 'Create Account' : 'Log In')}
          </button>
        </form>

        <div className="mt-8 text-center">
          <button
            onClick={() => setIsSignUp(!isSignUp)}
            className="text-[#27AAE1] text-sm font-bold hover:underline transition-all"
            style={{ textTransform: 'none !important' }}
          >
            {isSignUp ? 'Already have an account? Log In' : "Don't have an account? Join Beta"}
          </button>
        </div>
      </div>
    </div>
  );
}
