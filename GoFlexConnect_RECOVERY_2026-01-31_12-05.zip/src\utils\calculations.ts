import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Measurement, ThresholdConfig, ProjectStats, MetricType } from '../types';
import { LOGO_BASE64 } from '../assets/logo';

export function getMetricValue(measurement: Measurement, metric: MetricType): number {
  return measurement[metric] as number;
}

export function getColorForValue(value: number, metric: MetricType, thresholds: ThresholdConfig, benchmarkMode: boolean = false, rsrpTarget: number = -100): string {
  if (benchmarkMode && metric === 'rsrp') {
    return value >= rsrpTarget ? '#27AAE1' : '#ef4444'; 
  }
  if (metric === 'rsrp') {
    if (value >= thresholds.rsrp.good) return '#22c55e';
    if (value >= thresholds.rsrp.fair) return '#eab308';
    if (value >= -115) return '#f97316';
    return '#ef4444';
  }
  if (metric === 'sinr') {
    if (value >= thresholds.sinr.good) return '#22c55e';
    if (value >= thresholds.sinr.fair) return '#eab308';
    return '#ef4444';
  }
  return value >= -10 ? '#22c55e' : '#ef4444';
}

export function exportToCSV(measurements: Measurement[]): string {
  const headers = ['#', 'Timestamp', 'Carrier', 'Tech', 'RSRP', 'RSRQ', 'SINR'];
  const rows = measurements.map((m: any) => [
    m.locationNumber,
    new Date(m.timestamp).toISOString(),
    m.carrierName || 'T-Mobile',
    m.techType || 'LTE',
    m.rsrp, m.rsrq, m.sinr
  ]);
  return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
}

export async function exportToPDF(measurements: Measurement[], projectName: string, mapImage?: string | null, benchmarkMode: boolean = false, rsrpTarget: number = -100) {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  const blueGlow = [39, 170, 225];

  // DARK HEADER BACKGROUND
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, pageWidth, 45, 'F');

  // RENDER THE GLOW EFFECT
  const logoX = 14; const logoY = 10; const logoSize = 25;
  const centerX = logoX + (logoSize / 2);
  const centerY = logoY + (logoSize / 2);

  // Draw 15 concentric rings to simulate a soft radial glow
  for (let r = 18; r > 0; r--) {
    const alpha = (18 - r) / 100; // Very soft falloff
    doc.setGState(new (doc as any).GState({ opacity: alpha }));
    doc.setFillColor(blueGlow[0], blueGlow[1], blueGlow[2]);
    doc.circle(centerX, centerY, r, 'F');
  }

  // Restore opacity for logo and text
  doc.setGState(new (doc as any).GState({ opacity: 1.0 }));
  try { doc.addImage(LOGO_BASE64, 'PNG', logoX, logoY, logoSize, logoSize); } catch (e) {}

  // BRANDING: Professional Mixed Case
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text('GoFlexConnect', 44, 22);

  doc.setTextColor(blueGlow[0], blueGlow[1], blueGlow[2]);
  doc.setFontSize(10);
  doc.text(benchmarkMode ? `Compliance Report (Target: ${rsrpTarget}dBm)` : 'Pro Site Report', 44, 28);

  doc.setTextColor(148, 163, 184);
  doc.setFontSize(8);
  doc.text(`Project: ${projectName}`, 44, 36);

  const tableData = measurements.map((m: any, index) => [
    index + 1, m.carrierName || 'T-Mobile', m.techType || 'LTE',
    m.rsrp + ' dBm', m.rsrq + ' dB', m.sinr + ' dB',
    m.timestamp ? new Date(m.timestamp).toLocaleTimeString() : 'N/A'
  ]);

  autoTable(doc, {
    startY: 50,
    head: [['#', 'Carrier', 'Tech', 'RSRP', 'RSRQ', 'SINR', 'Time']],
    body: tableData,
    theme: 'striped',
    headStyles: { fillColor: [15, 23, 42], textColor: 255 },
    styles: { fontSize: 7 }
  });

  if (mapImage) {
    doc.addPage();
    doc.addImage(mapImage, 'JPEG', 15, 20, 180, 0);
  }
  return doc.output('blob');
}

export async function generateMapSnapshot(floorPlanUrl: string, measurements: Measurement[], benchmarkMode: boolean = false, rsrpTarget: number = -100): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d')!;
      canvas.width = 1200;
      canvas.height = (img.height / img.width) * 1200;
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      measurements.forEach(m => {
        const x = m.x * canvas.width; const y = m.y * canvas.height;
        ctx.beginPath(); ctx.arc(x, y, 12, 0, Math.PI * 2);
        ctx.fillStyle = benchmarkMode ? (m.rsrp >= rsrpTarget ? '#27AAE1' : '#ef4444') : (m.rsrp > -90 ? '#22c55e' : m.rsrp > -105 ? '#eab308' : '#ef4444');
        ctx.fill();
        ctx.strokeStyle = 'white'; ctx.lineWidth = 2; ctx.stroke();
      });
      resolve(canvas.toDataURL('image/jpeg', 0.8));
    };
    img.onerror = () => resolve('');
    img.src = floorPlanUrl;
  });
}
